import { IMG } from '@/lib/media';

// Seed data for local storage
const SEED_PRODUCTS = [
  {
    id: "prod-9",
    name: "FORTIFIED EMBROIDERED BLACK TEE",
    price: 1950,
    images: [
      "/images/embroidered-black/emb_black_front.jpg",
      "/images/embroidered-black/emb_black_back.jpg",
      "/images/embroidered-black/emb_black_detail_1.jpg",
      "/images/embroidered-black/emb_black_detail_2.jpg"
    ],
    colorImages: {
      "Black": [
        "/images/embroidered-black/emb_black_front.jpg",
        "/images/embroidered-black/emb_black_back.jpg",
        "/images/embroidered-black/emb_black_detail_1.jpg",
        "/images/embroidered-black/emb_black_detail_2.jpg"
      ],
      "White": [
        "/images/embroidered-white/emb_white_front.jpg",
        "/images/embroidered-white/emb_white_back.jpg",
        "/images/embroidered-white/emb_white_detail_front.jpg",
        "/images/embroidered-white/emb_white_detail_back.jpg"
      ]
    },
    description: "Introducing the Black embroider Classic oversized Tee showing the strong quieter point of different.\n\nThe front Tee is embroidered in the left chest ‘’FORTIFIED AND PERMANENT ART’’ and at the back the T-shirt is Screen print in Black in the top-centre with finished ribbed crewneck collar.\n\nThis T-shirt also maintains the best quality and warm fabric, crafted from the identical premium cotton fabric. This T-shirt stays true to the relaxed, oversized fit that defines Fortified Brand.\n\nSame weight, same GSM, same construction standards and the feeling of the fabric is warm.",
    collection: "New Arrivals",
    collections: ["New Arrivals", "Premium Cotton Collection", "Oversized Collection", "Best Sellers"],
    category: "Embroidered Tees",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Black", "White"],
    colorStock: { "Black": 10, "White": 10 },
    stock: 20,
    featured: true,
    created_date: "2026-07-17T08:00:00Z"
  },
  {
    id: "prod-5",
    name: "FORTIFIED EMBROIDERED WHITE TEE",
    price: 1950,
    images: [
      "/images/embroidered-white/emb_white_front.jpg",
      "/images/embroidered-white/emb_white_back.jpg",
      "/images/embroidered-white/emb_white_detail_front.jpg",
      "/images/embroidered-white/emb_white_detail_back.jpg"
    ],
    colorImages: {
      "White": [
        "/images/embroidered-white/emb_white_front.jpg",
        "/images/embroidered-white/emb_white_back.jpg",
        "/images/embroidered-white/emb_white_detail_front.jpg",
        "/images/embroidered-white/emb_white_detail_back.jpg"
      ],
      "Black": [
        "/images/embroidered-black/emb_black_front.jpg",
        "/images/embroidered-black/emb_black_back.jpg",
        "/images/embroidered-black/emb_black_detail_1.jpg",
        "/images/embroidered-black/emb_black_detail_2.jpg"
      ]
    },
    description: "Introducing the White embroider Classic oversized Tee showing the strong quieter point of different.\n\nThe front Tee is embroidered in the left chest ‘’FORTIFIED AND PERMANENT ART’’ and at the back the T-shirt is Screen print in Black in the top-centre with finished ribbed crewneck collar.\n\nThis T-shirt also maintains the best quality and warm fabric, crafted from the identical premium cotton fabric. This T-shirt stays true to the relaxed, oversized fit that defines Fortified Brand.\n\nSame weight, same GSM, same construction standards and the feeling of the fabric is warm.",
    collection: "New Arrivals",
    collections: ["New Arrivals", "Premium Cotton Collection", "Oversized Collection", "Best Sellers"],
    category: "Embroidered Tees",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Black", "White"],
    colorStock: { "Black": 10, "White": 10 },
    stock: 20,
    featured: true,
    created_date: "2026-07-15T08:00:00Z"
  },
  {
    id: "prod-8",
    name: "CLASSIC TEE FRONT PRINT BLACK",
    price: 1550,
    images: [
      "/images/classic-front-black/classic_black_front.jpg",
      "/images/classic-front-black/classic_black_back.jpg",
      "/images/classic-front-black/classic_black_detail.jpg",
      "/images/classic-front-black/classic_black_detail_2.jpg"
    ],
    colorImages: {
      "Black": [
        "/images/classic-front-black/classic_black_front.jpg",
        "/images/classic-front-black/classic_black_back.jpg",
        "/images/classic-front-black/classic_black_detail.jpg",
        "/images/classic-front-black/classic_black_detail_2.jpg"
      ],
      "White": [
        "/images/classic-front-white/classic_white_front.jpg",
        "/images/classic-front-white/classic_white_back.jpg",
        "/images/classic-front-white/classic_white_detail.jpg",
        "/images/classic-front-white/classic_white_detail_2.jpg"
      ]
    },
    description: "Introducing the FORTIFIED Classic Tee written in the from chest with Black Screen print showing Screen print FORTIFIED name of the oversized T-shirt.\n\nThe T-shirt maintains the best quality and warm fabric, crafted from identical premium cotton fabric and The T-shirt stays true as print branding to the relaxed oversized fit that defines Fortified.\n\nSame weight, same GSM, same construction standards and the feeling of the fabric is warm.",
    collection: "New Arrivals",
    collections: ["New Arrivals", "Premium Cotton Collection", "Oversized Collection", "Best Sellers"],
    category: "Printed Tees",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Black", "White"],
    colorStock: { "Black": 15, "White": 15 },
    stock: 30,
    featured: true,
    created_date: "2026-07-16T08:10:00Z"
  },
  {
    id: "prod-7",
    name: "CLASSIC TEE FRONT PRINT WHITE",
    price: 1550,
    images: [
      "/images/classic-front-white/classic_white_front.jpg",
      "/images/classic-front-white/classic_white_back.jpg",
      "/images/classic-front-white/classic_white_detail.jpg",
      "/images/classic-front-white/classic_white_detail_2.jpg"
    ],
    colorImages: {
      "White": [
        "/images/classic-front-white/classic_white_front.jpg",
        "/images/classic-front-white/classic_white_back.jpg",
        "/images/classic-front-white/classic_white_detail.jpg",
        "/images/classic-front-white/classic_white_detail_2.jpg"
      ],
      "Black": [
        "/images/classic-front-black/classic_black_front.jpg",
        "/images/classic-front-black/classic_black_back.jpg",
        "/images/classic-front-black/classic_black_detail.jpg",
        "/images/classic-front-black/classic_black_detail_2.jpg"
      ]
    },
    description: "Introducing the FORTIFIED Classic Tee written in the from chest with Black Screen print showing FORTIFIED name of the oversized T-shirt.\n\nThe T-shirt maintains the best quality and warm fabric, crafted from the identical premium cotton fabric and The Fortified T-shirt stays true as print branding to the relaxed oversized fit that defines Fortified.\n\nSame weight, same GSM, same construction standards and the feeling of the fabric is warm.",
    collection: "New Arrivals",
    collections: ["New Arrivals", "Premium Cotton Collection", "Oversized Collection", "Best Sellers"],
    category: "Printed Tees",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Black", "White"],
    colorStock: { "Black": 15, "White": 15 },
    stock: 30,
    featured: true,
    created_date: "2026-07-16T08:00:00Z"
  }
];

const getImageListForProduct = (p) => {
  return p.images && p.images.length > 0 ? p.images : [];
};

const getSeedForId = (id) => SEED_PRODUCTS.find(s => s.id === id);

let MOCK_PRODUCTS = [];
try {
  const stored = localStorage.getItem("fortified_products");
  if (stored) {
    const parsed = JSON.parse(stored);
    MOCK_PRODUCTS = parsed
      .filter(p => {
        const cat = (p.category || "").toLowerCase();
        const nm = (p.name || "").toLowerCase();
        const status = (p.status || "").toLowerCase();
        const avail = (p.availability || "").toLowerCase();
        const isComingSoon = status === "coming_soon" || status === "coming soon" || avail === "coming soon" || ["prod-1", "prod-2", "prod-3", "prod-10", "prod-11", "prod-12"].includes(p.id);
        const isExcluded = cat.includes("hoodie") || cat.includes("sweater") || cat.includes("pant") ||
                           nm.includes("hoodie") || nm.includes("sweater") || nm.includes("sweatpant") || nm.includes("pant") ||
                           isComingSoon;
        return !isExcluded;
      })
      .map(p => {
        const seed = getSeedForId(p.id);
        const name = seed ? seed.name : p.name;
        const description = seed ? seed.description : p.description;
        let images = (seed && seed.images && seed.images.length > 0)
          ? seed.images
          : getImageListForProduct(p);
        const colorImages = (seed && seed.colorImages) ? seed.colorImages : p.colorImages;
        return {
          ...p,
          name,
          description,
          images,
          colorImages
        };
      })
      .filter(p => p.images && p.images.length > 0);

    // Ensure all seed products exist in MOCK_PRODUCTS
    SEED_PRODUCTS.forEach(seed => {
      if (!MOCK_PRODUCTS.some(mp => mp.id === seed.id)) {
        MOCK_PRODUCTS.unshift(seed);
      }
    });

    localStorage.setItem("fortified_products", JSON.stringify(MOCK_PRODUCTS));
  } else {
    MOCK_PRODUCTS = SEED_PRODUCTS;
    localStorage.setItem("fortified_products", JSON.stringify(MOCK_PRODUCTS));
  }
} catch (e) {
  MOCK_PRODUCTS = SEED_PRODUCTS;
}

const saveProductsToStorage = (products) => {
  try {
    localStorage.setItem("fortified_products", JSON.stringify(products));
  } catch (e) {
    console.error("Failed to save products to localStorage", e);
  }
};

const MOCK_REVIEWS = [
  {
    id: "rev-1",
    product_id: "prod-1",
    author: "Zola M.",
    rating: 5,
    title: "Incredible Heavyweight Feel",
    body: "Incredible quality. The 280 GSM feel is thick and luxurious, holding its shape perfectly after washing.",
    created_date: "2026-07-12T10:00:00Z"
  },
  {
    id: "rev-2",
    product_id: "prod-1",
    author: "Liam K.",
    rating: 5,
    title: "Perfect Oversized Fit",
    body: "The perfect oversized fit. Hard to find tees with this drape.",
    created_date: "2026-07-13T12:00:00Z"
  },
  {
    id: "rev-3",
    product_id: "prod-2",
    author: "Naledi S.",
    rating: 5,
    title: "Superb drape and structure",
    body: "The drop shoulders look very modern and the double-needle stitching makes it feel indestructible. Absolutely buying more colors.",
    created_date: "2026-07-14T09:15:00Z"
  },
  {
    id: "rev-4",
    product_id: "prod-3",
    author: "Thabo M.",
    rating: 5,
    title: "Incredible Silk-Screen Print",
    body: "This is truly a wearable art piece. The high-contrast back graphics are thick and sharp. Amazing limited-edition drop.",
    created_date: "2026-07-15T14:30:00Z"
  },
  {
    id: "rev-5",
    product_id: "prod-5",
    author: "Jessica D.",
    rating: 5,
    title: "Masterpiece Embroidery",
    body: "Meticulous chain-stitch details. The contrast of the black embroidery on the heavy white tee is gorgeous. Highly recommended!",
    created_date: "2026-07-16T11:00:00Z"
  },
  {
    id: "rev-6",
    product_id: "prod-8",
    author: "Sipho N.",
    rating: 4,
    title: "Stunning Print Quality",
    body: "Bold print that doesn't fade. The fit is beautifully boxy. Only wish the collar was slightly softer, but it holds its shape extremely well.",
    created_date: "2026-07-18T16:45:00Z"
  },
  {
    id: "rev-7",
    product_id: "prod-9",
    author: "Marcus T.",
    rating: 5,
    title: "Elite Streetwear Standard",
    body: "The 280 GSM cotton feels heavy and structured, and the chest embroidery is extremely precise. Best black tee in my collection.",
    created_date: "2026-07-19T09:00:00Z"
  }
];

const SEED_ORDERS = [
  {
    id: "ord-1006",
    order_number: "FTD-982104",
    created_date: "2026-07-28T14:20:00Z",
    customer_name: "Zola Dlamini",
    customer_email: "zola.dlamini@mweb.co.za",
    customer_phone: "+27 82 456 7890",
    country: "South Africa",
    country_code: "ZA",
    country_flag: "🇿🇦",
    shipping_address: "14 Rosebank Road, Sandton, Johannesburg, 2196, 🇿🇦 South Africa",
    payment_method: "Card",
    payment_status: "Paid",
    subtotal: 1950,
    total: 1950,
    currency: "ZAR",
    status: "Delivered",
    tracking_number: "RAM-ZA-882194",
    items: [
      { product_id: "prod-9", name: "FORTIFIED EMBROIDERED BLACK TEE", size: "L", colour: "Black", quantity: 1, price: 1950, image: "/images/embroidered-black/emb_black_front.jpg" }
    ]
  },
  {
    id: "ord-1005",
    order_number: "FTD-982103",
    created_date: "2026-07-27T09:15:00Z",
    customer_name: "Marcus Thorne",
    customer_email: "marcus.t@gmail.com",
    customer_phone: "+27 71 892 1102",
    country: "South Africa",
    country_code: "ZA",
    country_flag: "🇿🇦",
    shipping_address: "88 Kloof Street, Gardens, Cape Town, 8001, 🇿🇦 South Africa",
    payment_method: "PayPal",
    payment_status: "Paid",
    subtotal: 2300,
    total: 2300,
    currency: "ZAR",
    status: "Shipped",
    tracking_number: "DHL-EX-99104",
    items: [
      { product_id: "prod-7", name: "CLASSIC TEE FRONT PRINT WHITE", size: "XL", colour: "White", quantity: 1, price: 1550, image: "/images/classic-front-white/classic_white_front.jpg" },
      { product_id: "prod-1", name: "MONOLITH HEAVYWEIGHT TEE", size: "M", colour: "Black", quantity: 1, price: 750, image: "/images/embroidered-black/emb_black_front.jpg" }
    ]
  },
  {
    id: "ord-1004",
    order_number: "FTD-982102",
    created_date: "2026-07-26T18:45:00Z",
    customer_name: "Jessica Daniels",
    customer_email: "jessica.daniels@yahoo.com",
    customer_phone: "+27 83 123 9988",
    country: "South Africa",
    country_code: "ZA",
    country_flag: "🇿🇦",
    shipping_address: "42 Florida Road, Morningside, Durban, 4001, 🇿🇦 South Africa",
    payment_method: "Card",
    payment_status: "Paid",
    subtotal: 3900,
    total: 3900,
    currency: "ZAR",
    status: "Processing",
    tracking_number: "RAM-ZA-449102",
    items: [
      { product_id: "prod-5", name: "FORTIFIED EMBROIDERED WHITE TEE", size: "M", colour: "White", quantity: 2, price: 1950, image: "/images/embroidered-white/emb_white_front.jpg" }
    ]
  },
  {
    id: "ord-1003",
    order_number: "FTD-982101",
    created_date: "2026-07-25T11:05:00Z",
    customer_name: "Sipho Ndlovu",
    customer_email: "sipho.ndlovu@gmail.com",
    customer_phone: "+27 76 554 1212",
    country: "South Africa",
    country_code: "ZA",
    country_flag: "🇿🇦",
    shipping_address: "105 Lynnwood Rd, Brooklyn, Pretoria, 0181, 🇿🇦 South Africa",
    payment_method: "Ozow",
    payment_status: "Paid",
    subtotal: 950,
    total: 950,
    currency: "ZAR",
    status: "Delivered",
    tracking_number: "RAM-ZA-118204",
    items: [
      { product_id: "prod-3", name: "ARCHIVE GRAPHIC TEE", size: "L", colour: "Black", quantity: 1, price: 950, image: "/images/classic-front-black/classic_black_front.jpg" }
    ]
  },
  {
    id: "ord-1002",
    order_number: "FTD-982100",
    created_date: "2026-07-24T16:30:00Z",
    customer_name: "Alex Vance",
    customer_email: "alex.vance@uk-design.co.uk",
    customer_phone: "+44 7700 900077",
    country: "United Kingdom",
    country_code: "GB",
    country_flag: "🇬🇧",
    shipping_address: "12 Regent Street, Soho, London, W1B 5RL, 🇬🇧 United Kingdom",
    payment_method: "Card",
    payment_status: "Paid",
    subtotal: 3900,
    total: 3900,
    currency: "ZAR",
    status: "Pending",
    tracking_number: "DHL-UK-88491",
    items: [
      { product_id: "prod-9", name: "FORTIFIED EMBROIDERED BLACK TEE", size: "XL", colour: "Black", quantity: 2, price: 1950, image: "/images/embroidered-black/emb_black_front.jpg" }
    ]
  },
  {
    id: "ord-1001",
    order_number: "FTD-982099",
    created_date: "2026-07-22T08:10:00Z",
    customer_name: "Naledi Soto",
    customer_email: "naledi@soto.co.za",
    customer_phone: "+27 82 991 0022",
    country: "South Africa",
    country_code: "ZA",
    country_flag: "🇿🇦",
    shipping_address: "55 West Street, Sandton, Johannesburg, 2196, 🇿🇦 South Africa",
    payment_method: "Apple Pay",
    payment_status: "Paid",
    subtotal: 800,
    total: 800,
    currency: "ZAR",
    status: "Delivered",
    tracking_number: "RAM-ZA-773019",
    items: [
      { product_id: "prod-2", name: "TEMPLE COTTON BOX TEE", size: "S", colour: "White", quantity: 1, price: 800, image: "/images/classic-front-white/classic_white_front.jpg" }
    ]
  }
];

let MOCK_ORDERS = [];
try {
  const storedOrders = localStorage.getItem("fortified_orders");
  if (storedOrders) {
    MOCK_ORDERS = JSON.parse(storedOrders);
  } else {
    MOCK_ORDERS = SEED_ORDERS;
    localStorage.setItem("fortified_orders", JSON.stringify(MOCK_ORDERS));
  }
} catch (e) {
  MOCK_ORDERS = SEED_ORDERS;
}

const saveOrdersToStorage = (orders) => {
  try {
    localStorage.setItem("fortified_orders", JSON.stringify(orders));
  } catch (e) {
    console.error("Failed to save orders to localStorage", e);
  }
};

// Helper to sanitize product data
const sanitizeProduct = (p) => {
  if (!p) return p;
  const product = { ...p };

  // Keep only valid non-empty image URLs
  product.images = (product.images || []).filter(img => typeof img === 'string' && img.trim().length > 0);

  // T-shirt sizes must start from xs to xl
  product.sizes = ["XS", "S", "M", "L", "XL"];

  // Strictly use only Black and White for all products
  product.colors = ["Black", "White"];

  // Sync colorStock and stock
  const newColorStock = {
    "Black": (p.colorStock && p.colorStock["Black"] !== undefined) ? p.colorStock["Black"] : 10,
    "White": (p.colorStock && p.colorStock["White"] !== undefined) ? p.colorStock["White"] : 10
  };
  product.colorStock = newColorStock;
  product.stock = newColorStock["Black"] + newColorStock["White"];

  return product;
};

// Pure local async execution without external network dependencies
const execLocal = async (fn) => {
  const res = fn();
  return Array.isArray(res) ? res.map(sanitizeProduct) : sanitizeProduct(res);
};

export const base44 = {
  get asServiceRole() {
    return new Proxy({}, {
      get() {
        return {};
      }
    });
  },
  entities: {
    Product: {
      list: (order, limit) => execLocal(() => {
        let sorted = [...MOCK_PRODUCTS];
        if (order === "-created_date") {
          sorted.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
        } else if (order === "created_date") {
          sorted.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
        }
        if (limit) {
          sorted = sorted.slice(0, limit);
        }
        return sorted;
      }),
      get: (id) => execLocal(() => {
        return MOCK_PRODUCTS.find(p => p.id === id) || MOCK_PRODUCTS[0];
      }),
      filter: (query, order) => execLocal(() => {
        let filtered = [...MOCK_PRODUCTS];
        if (query?.category) {
          const cat = query.category.toLowerCase();
          filtered = filtered.filter(p => {
            const pCat = p.category.toLowerCase();
            if (cat === "t-shirts") {
              return pCat === "t-shirts" || 
                     pCat.includes("embroidered") || 
                     pCat.includes("printed");
            }
            if (cat === "embroidered tees") {
              return pCat.includes("embroidered");
            }
            if (cat === "printed tees") {
              return pCat.includes("printed");
            }
            return pCat === cat;
          });
        }
        if (query?.collection) {
          const queryCol = query.collection.toLowerCase();
          filtered = filtered.filter(p => {
            if (Array.isArray(p.collections)) {
              return p.collections.some(c => c.toLowerCase() === queryCol);
            }
            if (Array.isArray(p.collection)) {
              return p.collection.some(c => c.toLowerCase() === queryCol);
            }
            return p.collection?.toLowerCase() === queryCol;
          });
        }
        if (order === "-created_date") {
          filtered.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
        } else if (order === "created_date") {
          filtered.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
        }
        return filtered;
      }),
      create: (data) => execLocal(() => {
        const newProd = {
          id: data.id || `prod-${Date.now()}`,
          name: data.name,
          price: Number(data.price) || 0,
          images: data.images || [],
          description: data.description || "",
          collection: data.collection || "New Arrivals",
          category: data.category || "T-Shirts",
          sizes: data.sizes || ["S", "M", "L", "XL"],
          colors: data.colors || ["Black"],
          colorStock: data.colorStock || { "Black": 10 },
          stock: Number(data.stock) || 10,
          featured: !!data.featured,
          created_date: new Date().toISOString()
        };
        MOCK_PRODUCTS.push(newProd);
        saveProductsToStorage(MOCK_PRODUCTS);
        return newProd;
      }),
      update: (id, data) => execLocal(() => {
        const idx = MOCK_PRODUCTS.findIndex(p => p.id === id);
        if (idx !== -1) {
          MOCK_PRODUCTS[idx] = { ...MOCK_PRODUCTS[idx], ...data };
          saveProductsToStorage(MOCK_PRODUCTS);
          return MOCK_PRODUCTS[idx];
        }
        return MOCK_PRODUCTS[0];
      }),
      delete: (id) => execLocal(() => {
        MOCK_PRODUCTS = MOCK_PRODUCTS.filter(p => p.id !== id);
        saveProductsToStorage(MOCK_PRODUCTS);
        return { id, success: true };
      })
    },
    Review: {
      filter: (query) => Promise.resolve(MOCK_REVIEWS.filter(r => r.product_id === query?.product_id)),
      create: (data) => Promise.resolve(() => {
        const newReview = { ...data, id: `rev-${Date.now()}`, created_date: new Date().toISOString() };
        MOCK_REVIEWS.push(newReview);
        return newReview;
      })()
    },
    Order: {
      list: (order, limit) => Promise.resolve((() => {
        let sorted = [...MOCK_ORDERS];
        if (order === "-created_date") {
          sorted.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
        } else if (order === "created_date") {
          sorted.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
        }
        if (limit) sorted = sorted.slice(0, limit);
        return sorted;
      })()),
      get: (id) => Promise.resolve(MOCK_ORDERS.find(o => o.id === id || o.order_number === id) || MOCK_ORDERS[0]),
      filter: (query) => Promise.resolve((() => {
        let filtered = [...MOCK_ORDERS];
        if (query?.status) {
          filtered = filtered.filter(o => o.status?.toLowerCase() === query.status.toLowerCase());
        }
        return filtered;
      })()),
      create: (data) => Promise.resolve((() => {
        const newOrd = {
          id: `ord-${Date.now()}`,
          order_number: data.order_number || `FTD-${Date.now().toString().slice(-6)}`,
          created_date: new Date().toISOString(),
          payment_status: "Paid",
          ...data
        };
        MOCK_ORDERS.unshift(newOrd);
        saveOrdersToStorage(MOCK_ORDERS);

        // Deduct inventory automatically on order creation
        if (Array.isArray(newOrd.items)) {
          newOrd.items.forEach(item => {
            const p = MOCK_PRODUCTS.find(prod => prod.id === item.product_id || prod.name === item.name);
            if (p) {
              const qty = Number(item.quantity) || 1;
              p.stock = Math.max(0, (p.stock || 0) - qty);
              if (p.colorStock && item.colour && p.colorStock[item.colour] !== undefined) {
                p.colorStock[item.colour] = Math.max(0, p.colorStock[item.colour] - qty);
              }
            }
          });
          saveProductsToStorage(MOCK_PRODUCTS);
        }

        return newOrd;
      })()),
      update: (id, data) => Promise.resolve((() => {
        const idx = MOCK_ORDERS.findIndex(o => o.id === id || o.order_number === id);
        if (idx !== -1) {
          MOCK_ORDERS[idx] = { ...MOCK_ORDERS[idx], ...data };
          saveOrdersToStorage(MOCK_ORDERS);
          return MOCK_ORDERS[idx];
        }
        return null;
      })()),
      delete: (id) => Promise.resolve((() => {
        MOCK_ORDERS = MOCK_ORDERS.filter(o => o.id !== id && o.order_number !== id);
        saveOrdersToStorage(MOCK_ORDERS);
        return { success: true };
      })())
    }
  },
  auth: {
    me: async () => {
      const stored = localStorage.getItem("fortified_user");
      return stored ? JSON.parse(stored) : null;
    },
    loginViaEmailPassword: async (email) => {
      const mockUser = { email, id: "usr-1", name: email.split("@")[0] };
      localStorage.setItem("fortified_user", JSON.stringify(mockUser));
      return { user: mockUser };
    },
    register: async (data) => {
      return { email: data.email, status: "pending_verification" };
    },
    verifyOtp: async (data) => {
      const mockUser = { email: data.email, id: "usr-1", name: data.email?.split("@")[0] || "User" };
      localStorage.setItem("fortified_user", JSON.stringify(mockUser));
      return { access_token: "mock-access-token", user: mockUser };
    },
    resendOtp: async () => {
      return { success: true };
    },
    resetPasswordRequest: async () => {
      return { success: true };
    },
    resetPassword: async () => {
      return { success: true };
    },
    loginWithProvider: (provider, redirectUrl) => {
      const mockUser = { email: "user@fortified.com", id: "usr-google", name: "Fortified Member" };
      localStorage.setItem("fortified_user", JSON.stringify(mockUser));
      if (redirectUrl) window.location.href = redirectUrl;
    },
    logout: () => {
      localStorage.removeItem("fortified_user");
      window.location.reload();
    },
    redirectToLogin: () => {
      window.location.href = "/login";
    },
    setToken: () => {}
  },
  integrations: {
    Core: {
      SendEmail: async (params) => {
        console.log("Mock email sent:", params);
        try {
          const storedEmails = JSON.parse(localStorage.getItem("fortified_sent_emails") || "[]");
          storedEmails.unshift({
            id: `email-${Date.now()}`,
            timestamp: new Date().toISOString(),
            to: params.to || params.recipient || "customer@fortified.co.za",
            subject: params.subject || "FORTIFIED Notification",
            body: params.body || params.message || params.content || "",
            status: "Delivered",
            type: params.type || "Dispatch Notice"
          });
          localStorage.setItem("fortified_sent_emails", JSON.stringify(storedEmails.slice(0, 50)));
        } catch (e) {
          console.error("Failed to log email history", e);
        }
        return { success: true, messageId: `msg-${Date.now()}` };
      }
    }
  }
};
