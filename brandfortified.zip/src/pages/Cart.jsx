import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Check, Globe, Search, MapPin, Tag, Percent } from "lucide-react";
import { useCart } from "@/lib/CartContext";
import { base44 } from "@/api/base44Client";
import { zar } from "@/lib/media";
import { ALL_COUNTRIES, getCountryByCode } from "@/lib/countries";

const payments = ["Card", "PayPal", "Apple Pay", "Google Pay", "PayFast", "Ozow", "Yoco", "EFT"];

export default function Cart() {
  const {
    items,
    updateQty,
    removeItem,
    subtotal,
    rawSubtotal,
    totalSavings,
    isSaleActive,
    discountPercent,
    appliedPromoCode,
    applyPromoCode,
    removePromoCode,
    clear,
  } = useCart();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [pay, setPay] = useState("Card");
  const [placed, setPlaced] = useState(null);
  const [promoInput, setPromoInput] = useState("");
  const [promoMessage, setPromoMessage] = useState({ type: "", text: "" });
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    countryCode: "ZA",
    address: "",
    city: "",
    postalCode: ""
  });
  const [countrySearch, setCountrySearch] = useState("");
  const [countryDropdownOpen, setCountryDropdownOpen] = useState(false);

  const shipping = 0;
  const total = subtotal + shipping;

  const handleApplyPromo = () => {
    const res = applyPromoCode(promoInput);
    if (res.success) {
      setPromoMessage({ type: "success", text: res.message });
      setPromoInput("");
    } else {
      setPromoMessage({ type: "error", text: res.message });
    }
  };

  const selectedCountry = getCountryByCode(form.countryCode);
  const filteredCountries = ALL_COUNTRIES.filter(
    (c) =>
      c.name.toLowerCase().includes(countrySearch.toLowerCase()) ||
      c.code.toLowerCase().includes(countrySearch.toLowerCase()) ||
      c.phone.includes(countrySearch)
  );

  const placeOrder = async () => {
    const fullAddress = `${form.address}${form.city ? `, ${form.city}` : ""}${form.postalCode ? ` ${form.postalCode}` : ""}, ${selectedCountry.flag} ${selectedCountry.name}`;
    const order = await base44.entities.Order.create({
      order_number: `FTD-${Date.now().toString().slice(-6)}`,
      items: items.map(({ product_id, name, size, colour, quantity, price, image }) => ({ product_id, name, size, colour, quantity, price, image })),
      subtotal, total, currency: "ZAR",
      customer_name: form.name, 
      customer_email: form.email,
      customer_phone: `${selectedCountry.phone} ${form.phone}`.trim(),
      country: selectedCountry.name,
      country_code: selectedCountry.code,
      country_flag: selectedCountry.flag,
      shipping_address: fullAddress, 
      payment_method: pay, 
      status: "pending",
      promo_code: appliedPromoCode || null,
      discount_amount: totalSavings || 0,
    });
    clear();
    setPlaced(order);
  };

  if (placed) {
    const itemsList = (placed.items || []).map((i) => `• ${i.name} (${i.size} / ${i.colour}) x${i.quantity}`).join("\n");
    const waMessage = `*FORTIFIED BRAND - ORDER CONFIRMATION* 🖤

Thank you for choosing FORTIFIED! Your order has been successfully placed.

*Order Summary:*
• Order Number: ${placed.order_number}
• Customer: ${placed.customer_name}
• Email: ${placed.customer_email}
• Phone: ${placed.customer_phone || "N/A"}
• Destination: ${placed.country_flag || "🌐"} ${placed.country || "Worldwide"}
• Address: ${placed.shipping_address}
• Payment Method: ${placed.payment_method}
• Total: ${zar(placed.total)}

*Items:*
${itemsList || "• Standard Fit Tee"}

*Join our Ecosystem:*
📸 Instagram: https://www.instagram.com/fortified_brand
🎵 TikTok: https://www.tiktok.com/@fortified_brand
✖️ X (Twitter): https://x.com/fortified98?s=11

*Contact:*
📞 WhatsApp Support: +27 68 594 0131
✉️ Email: fortifiedbrand31@gmail.com

Thank you for standing different with FORTIFIED.`;

    const waLink = `https://wa.me/27685940131?text=${encodeURIComponent(waMessage)}`;

    return (
      <div className="mx-auto flex max-w-2xl flex-col items-center px-6 pb-28 pt-48 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-full border border-green-500 bg-green-500/10"><Check className="h-7 w-7 text-green-400" /></div>
        <h1 className="mt-8 font-display text-4xl font-black tracking-monolith text-white">Order Confirmed</h1>
        <p className="mt-3 font-mono text-xs uppercase tracking-[0.2em] text-[#A8A8A8]">{placed.order_number}</p>
        
        <p className="mt-6 text-sm text-[#A8A8A8] max-w-md leading-relaxed">
          Thank you for choosing FORTIFIED. To complete any pending payment steps, receive live updates, and join our elite streetwear ecosystem, click the button below to send your confirmation via WhatsApp.
        </p>

        {/* WhatsApp Message Preview Box */}
        <div className="mt-8 w-full max-w-lg border border-neutral-800 bg-[#0A0A0A]/80 p-6 text-left rounded-lg shadow-2xl backdrop-blur-md">
          <div className="flex items-center justify-between border-b border-neutral-900 pb-3 mb-4">
            <span className="flex items-center gap-2 font-mono text-[9px] uppercase tracking-widest text-[#A8A8A8]">
              <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" />
              WhatsApp Message Preview
            </span>
            <span className="font-mono text-[9px] text-[#555] uppercase">To: +27 68 594 0131</span>
          </div>
          <pre className="whitespace-pre-wrap font-sans text-xs text-neutral-300 leading-relaxed font-light max-h-[250px] overflow-y-auto pr-2 custom-scrollbar">
            {waMessage}
          </pre>
        </div>

        <div className="mt-8 flex flex-col sm:flex-row gap-4 w-full justify-center">
          <a
            href={waLink}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-3 bg-green-500 hover:bg-green-600 text-white font-mono text-xs uppercase tracking-[0.15em] px-8 py-4 transition-all duration-300 shadow-lg shadow-green-500/10 hover:shadow-green-500/20 hover:scale-[1.02] cursor-pointer"
          >
            <svg className="h-4 w-4 fill-current" viewBox="0 0 24 24">
              <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.457L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.825 1.451 5.436 0 9.86-4.42 9.863-9.864.001-2.637-1.03-5.114-2.905-6.99C16.554 1.875 14.09 1.847 11.46 1.847c-5.437 0-9.865 4.421-9.868 9.865-.001 1.748.47 3.454 1.362 4.965l-.946 3.454 3.535-.927zM15.8 12.186c-.223-.111-1.32-.652-1.524-.726-.205-.075-.354-.112-.502.111-.148.223-.574.726-.704.875-.13.149-.26.168-.484.056-.223-.111-.944-.348-1.799-1.111-.665-.593-1.114-1.326-1.245-1.549-.13-.223-.014-.344.098-.455.1-.1.223-.26.335-.39.112-.13.149-.223.223-.372.075-.149.037-.279-.018-.39-.056-.112-.502-1.21-.688-1.654-.181-.437-.365-.377-.502-.384-.13-.007-.279-.008-.428-.008-.149 0-.391.056-.595.279-.205.223-.781.763-.781 1.86s.799 2.158.91 2.307c.112.149 1.572 2.4 3.81 3.361.533.228.948.365 1.272.468.536.171 1.024.147 1.41.09.43-.063 1.32-.539 1.505-1.059.185-.519.185-.964.13-1.058-.056-.094-.205-.149-.428-.261z"/>
            </svg>
            Send WhatsApp Confirmation
          </a>
          <Link
            to="/shop"
            className="inline-flex items-center justify-center border border-neutral-800 bg-neutral-950 hover:bg-neutral-900 text-[#A8A8A8] hover:text-white font-mono text-xs uppercase tracking-[0.15em] px-8 py-4 transition-all duration-300"
          >
            Continue Shopping
          </Link>
        </div>
      </div>
    );
  }

  if (items.length === 0)
    return (
      <div className="mx-auto flex max-w-xl flex-col items-center px-6 pb-28 pt-48 text-center">
        <h1 className="font-display text-5xl font-black tracking-monolith text-white">Your bag is empty</h1>
        <Link to="/shop" className="mt-10 bg-white px-9 py-4 font-mono text-xs uppercase tracking-[0.25em] text-black hover:bg-[#A8A8A8]">Shop Collection</Link>
      </div>
    );

  return (
    <div className="mx-auto max-w-[1400px] px-6 pb-28 pt-36 md:px-12">
      <h1 className="font-display text-5xl font-black tracking-monolith text-white md:text-7xl">Checkout</h1>

      <div className="mt-14 grid gap-16 lg:grid-cols-[1.4fr_1fr]">
        <div>
          {/* Step indicator */}
          <div className="mb-10 flex gap-6">
            {["Bag", "Details", "Payment"].map((s, i) => (
              <button key={s} onClick={() => setStep(i + 1)} className={`font-mono text-[10px] uppercase tracking-[0.2em] ${step === i + 1 ? "text-white" : "text-[#555]"}`}>
                {`0${i + 1} · ${s}`}
              </button>
            ))}
          </div>

          {step === 1 && (
            <div>
              {items.map((i) => (
                <div key={i.key} className="flex gap-5 border-b hairline py-6">
                  <img src={i.image} alt={i.name} className="h-28 w-24 object-cover" />
                  <div className="flex flex-1 flex-col justify-between">
                    <div>
                      <p className="text-white">{i.name}</p>
                      <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-[#A8A8A8]">Size {i.size} · {i.colour}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <input type="number" min={1} value={i.quantity} onChange={(e) => updateQty(i.key, parseInt(e.target.value) || 1)} className="w-16 border hairline bg-transparent px-3 py-2 font-mono text-sm text-white" />
                      <button onClick={() => removeItem(i.key)} className="font-mono text-[10px] uppercase tracking-[0.2em] text-[#555] hover:text-white">Remove</button>
                    </div>
                  </div>
                  <div className="flex flex-col items-end justify-center">
                    {i.isSaleActive ? (
                      <>
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-xs text-[#666] line-through">{zar(i.originalPrice * i.quantity)}</span>
                          <span className="font-mono text-[9px] text-red-400 font-bold bg-red-950/60 px-1 py-0.2 rounded border border-red-900/50">-{i.discountPercent}%</span>
                        </div>
                        <span className="font-mono text-sm font-bold text-white">{zar(i.price * i.quantity)}</span>
                      </>
                    ) : (
                      <span className="font-mono text-sm text-white">{zar(i.price * i.quantity)}</span>
                    )}
                  </div>
                </div>
              ))}
              <button onClick={() => setStep(2)} className="mt-8 w-full bg-white py-4 font-mono text-xs uppercase tracking-[0.25em] text-black hover:bg-[#A8A8A8]">Continue to Details</button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block mb-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-[#A8A8A8]">
                    Full Name *
                  </label>
                  <input
                    placeholder="John Doe"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full border hairline bg-transparent px-4 py-3.5 font-mono text-sm text-white placeholder:text-[#555] focus:border-white outline-none"
                  />
                </div>
                <div>
                  <label className="block mb-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-[#A8A8A8]">
                    Email Address *
                  </label>
                  <input
                    placeholder="john@example.com"
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="w-full border hairline bg-transparent px-4 py-3.5 font-mono text-sm text-white placeholder:text-[#555] focus:border-white outline-none"
                  />
                </div>
              </div>

              {/* International Country Selector with Flags */}
              <div className="relative">
                <label className="block mb-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-[#A8A8A8] flex items-center justify-between">
                  <span>Destination Country / Region *</span>
                  <span className="text-white flex items-center gap-1">
                    <Globe className="h-3 w-3 text-white" />
                    <span>Worldwide Shipping</span>
                  </span>
                </label>
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setCountryDropdownOpen(!countryDropdownOpen)}
                    className="w-full flex items-center justify-between border hairline bg-neutral-950 px-4 py-3.5 font-mono text-sm text-white text-left focus:border-white transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-3">
                      <span className="text-xl leading-none">{selectedCountry.flag}</span>
                      <span className="font-sans font-medium text-white">{selectedCountry.name}</span>
                      <span className="text-xs text-[#777]">({selectedCountry.code})</span>
                    </span>
                    <span className="font-mono text-xs text-[#A8A8A8]">{selectedCountry.phone} ▼</span>
                  </button>

                  {countryDropdownOpen && (
                    <div className="absolute left-0 right-0 top-full z-50 mt-1 max-h-80 overflow-y-auto border border-neutral-800 bg-[#0A0A0A] p-2 shadow-2xl backdrop-blur-xl custom-scrollbar">
                      <div className="sticky top-0 z-10 bg-[#0A0A0A] pb-2 pt-1 px-1">
                        <div className="relative flex items-center">
                          <Search className="absolute left-3 h-3.5 w-3.5 text-[#666]" />
                          <input
                            type="text"
                            placeholder="Type to search country..."
                            value={countrySearch}
                            onChange={(e) => setCountrySearch(e.target.value)}
                            autoFocus
                            className="w-full border border-neutral-800 bg-neutral-900 pl-9 pr-3 py-2.5 font-mono text-xs text-white placeholder:text-[#555] focus:border-neutral-600 outline-none"
                          />
                        </div>
                      </div>
                      <div className="space-y-0.5 mt-1">
                        {filteredCountries.map((c) => (
                          <button
                            key={c.code}
                            type="button"
                            onClick={() => {
                              setForm({ ...form, countryCode: c.code });
                              setCountryDropdownOpen(false);
                              setCountrySearch("");
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2.5 text-left font-mono text-xs transition-colors rounded-sm cursor-pointer ${
                              form.countryCode === c.code
                                ? "bg-white text-black font-semibold"
                                : "text-[#ccc] hover:bg-neutral-900 hover:text-white"
                            }`}
                          >
                            <span className="flex items-center gap-3">
                              <span className="text-xl leading-none">{c.flag}</span>
                              <span className="font-sans">{c.name}</span>
                            </span>
                            <span className={`text-[11px] ${form.countryCode === c.code ? "text-black/80 font-bold" : "text-[#777]"}`}>
                              {c.phone}
                            </span>
                          </button>
                        ))}
                        {filteredCountries.length === 0 && (
                          <p className="px-3 py-4 text-center font-mono text-xs text-[#666]">
                            No country found matching "{countrySearch}"
                          </p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Phone Input with Country Code */}
              <div>
                <label className="block mb-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-[#A8A8A8]">
                  Phone / WhatsApp Number (for Delivery Tracking)
                </label>
                <div className="flex">
                  <div className="flex items-center gap-2 border border-r-0 hairline bg-neutral-900/80 px-3.5 py-3.5 font-mono text-xs text-white">
                    <span className="text-base">{selectedCountry.flag}</span>
                    <span className="text-white font-bold">{selectedCountry.phone}</span>
                  </div>
                  <input
                    placeholder="82 123 4567"
                    type="tel"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    className="w-full flex-1 border hairline bg-transparent px-4 py-3.5 font-mono text-sm text-white placeholder:text-[#555] focus:border-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block mb-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-[#A8A8A8]">
                  Street Address *
                </label>
                <textarea
                  placeholder="House/Building Number, Street Name, District"
                  rows={2}
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  className="w-full border hairline bg-transparent px-4 py-3.5 font-mono text-sm text-white placeholder:text-[#555] focus:border-white outline-none resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block mb-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-[#A8A8A8]">
                    City / Town
                  </label>
                  <input
                    placeholder="City"
                    value={form.city}
                    onChange={(e) => setForm({ ...form, city: e.target.value })}
                    className="w-full border hairline bg-transparent px-4 py-3.5 font-mono text-sm text-white placeholder:text-[#555] focus:border-white outline-none"
                  />
                </div>
                <div>
                  <label className="block mb-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-[#A8A8A8]">
                    Postal / Zip Code
                  </label>
                  <input
                    placeholder="0000"
                    value={form.postalCode}
                    onChange={(e) => setForm({ ...form, postalCode: e.target.value })}
                    className="w-full border hairline bg-transparent px-4 py-3.5 font-mono text-sm text-white placeholder:text-[#555] focus:border-white outline-none"
                  />
                </div>
              </div>

              {/* Express Worldwide Delivery Notification Banner */}
              <div className="flex items-center gap-3.5 border border-neutral-800 bg-neutral-950 p-4 rounded-sm">
                <span className="text-2xl leading-none">{selectedCountry.flag}</span>
                <div className="font-mono text-[11px] flex-1">
                  <p className="text-white font-medium">Worldwide Express Courier to <span className="underline font-bold text-white">{selectedCountry.name}</span></p>
                  <p className="text-[#888] text-[10px] mt-0.5">Complimentary door-to-door express dispatch with live tracking</p>
                </div>
              </div>

              <button
                disabled={!form.name || !form.email || !form.address}
                onClick={() => setStep(3)}
                className="w-full bg-white py-4 font-mono text-xs uppercase tracking-[0.25em] text-black hover:bg-[#A8A8A8] disabled:opacity-40 transition-colors cursor-pointer"
              >
                Continue to Payment
              </button>
            </div>
          )}

          {step === 3 && (
            <div>
              <div className="grid grid-cols-3 gap-3">
                {payments.map((p) => (
                  <button key={p} onClick={() => setPay(p)} className={`border py-4 font-mono text-[10px] uppercase tracking-[0.15em] transition-colors ${pay === p ? "border-white bg-white text-black" : "hairline text-[#A8A8A8] hover:text-white"}`}>{p}</button>
                ))}
              </div>

              {pay === "PayPal" && (
                <div className="mt-8 border border-neutral-800 bg-neutral-950 p-6 rounded-none">
                  <h3 className="font-mono text-xs uppercase tracking-[0.2em] text-white">PayPal Payment Details</h3>
                  <p className="mt-3 text-sm text-[#A8A8A8] leading-relaxed">
                    To complete your purchase via PayPal, please send the total of <span className="text-white font-mono">{zar(total)}</span> to our PayPal handle:
                  </p>
                  <div className="mt-4 flex items-center justify-between bg-neutral-900 border border-neutral-800 p-4">
                    <div>
                      <p className="font-mono text-xs uppercase tracking-wider text-[#A8A8A8]">Recipient</p>
                      <p className="mt-1 font-sans text-sm font-bold text-white">@VumileTshazi</p>
                    </div>
                    <a 
                      href="https://paypal.me/VumileTshazi" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-white text-black hover:bg-[#A8A8A8] transition-colors px-4 py-2 font-mono text-[10px] uppercase tracking-wider"
                    >
                      Pay Now
                    </a>
                  </div>
                  <p className="mt-4 text-[11px] text-[#555] font-mono leading-relaxed">
                    Note: After making the payment, please click "Place Order" below to finalize your booking details in our system.
                  </p>
                </div>
              )}

              <button onClick={placeOrder} className="mt-8 w-full bg-white py-4 font-mono text-xs uppercase tracking-[0.25em] text-black hover:bg-[#A8A8A8]">Place Order · {zar(total)}</button>
              <p className="mt-4 text-center font-mono text-[10px] uppercase tracking-[0.15em] text-[#555]">Secure checkout · Guest checkout available</p>
            </div>
          )}
        </div>

        <aside className="h-fit border hairline p-8 space-y-6">
          <h3 className="font-mono text-xs uppercase tracking-[0.3em] text-white">Summary</h3>
          
          <div className="space-y-3">
            {isSaleActive && totalSavings > 0 ? (
              <>
                <div className="flex justify-between text-sm text-[#888]">
                  <span>Standard Price</span>
                  <span className="font-mono line-through">{zar(rawSubtotal)}</span>
                </div>
                <div className="flex justify-between text-sm text-emerald-400 font-bold">
                  <span className="flex items-center gap-1.5">
                    <Tag className="h-3.5 w-3.5" /> Promo Discount ({appliedPromoCode})
                  </span>
                  <span className="font-mono">-{zar(totalSavings)}</span>
                </div>
                <div className="flex justify-between text-sm text-[#A8A8A8]">
                  <span>Discounted Subtotal</span>
                  <span className="font-mono text-white font-bold">{zar(subtotal)}</span>
                </div>
              </>
            ) : (
              <div className="flex justify-between text-sm text-[#A8A8A8]">
                <span>Subtotal</span>
                <span className="font-mono text-white font-bold">{zar(subtotal)}</span>
              </div>
            )}
            <div className="flex justify-between text-sm text-[#A8A8A8]">
              <span>Shipping</span>
              <span className="font-mono text-white">Complimentary</span>
            </div>
            <div className="mt-4 flex justify-between border-t hairline pt-4">
              <span className="font-mono text-xs uppercase tracking-[0.2em] text-white">Total</span>
              <span className="font-mono text-lg font-bold text-white">{zar(total)}</span>
            </div>
          </div>

          {/* Promo Code Input & Status Section */}
          <div className="pt-4 border-t hairline space-y-3">
            <span className="block font-mono text-[10px] uppercase tracking-[0.2em] text-[#A8A8A8]">
              Promo / Coupon Code
            </span>

            {appliedPromoCode ? (
              <div className="border border-emerald-500/40 bg-emerald-950/20 p-3 rounded flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Tag className="h-4 w-4 text-emerald-400" />
                  <div>
                    <p className="font-mono text-xs font-bold text-emerald-400 uppercase tracking-wider">
                      {appliedPromoCode}
                    </p>
                    <p className="font-mono text-[9px] text-[#aaa]">
                      {discountPercent}% Discount Applied
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    removePromoCode();
                    setPromoMessage({ type: "info", text: "Promo code removed." });
                  }}
                  className="font-mono text-[9px] uppercase tracking-wider text-red-400 hover:text-red-300 underline font-bold"
                >
                  Remove
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="e.g. FORTIFIED10"
                    value={promoInput}
                    onChange={(e) => setPromoInput(e.target.value.toUpperCase())}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleApplyPromo();
                      }
                    }}
                    className="flex-1 border hairline bg-neutral-950 px-3 py-2.5 font-mono text-xs text-white placeholder:text-[#555] uppercase focus:border-white outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleApplyPromo}
                    className="bg-white text-black font-mono text-xs uppercase tracking-wider px-4 py-2.5 hover:bg-[#ccc] transition-colors font-bold cursor-pointer"
                  >
                    Apply
                  </button>
                </div>
                {promoMessage.text && (
                  <p className={`font-mono text-[10px] ${promoMessage.type === "success" ? "text-emerald-400 font-bold" : promoMessage.type === "error" ? "text-red-400 font-bold" : "text-[#aaa]"}`}>
                    {promoMessage.text}
                  </p>
                )}
                <p className="font-mono text-[9px] text-[#666]">
                  Enter your promotional code to activate special sales discounts.
                </p>
              </div>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}