import React, { useState } from "react";
import { motion } from "framer-motion";
import Reveal from "@/components/Reveal";
import { IMG } from "@/lib/media";
import Lightbox from "@/components/Lightbox";
import CampaignVideoPlayer from "@/components/CampaignVideoPlayer";

const shots = [
  { img: IMG.lookbook0, title: "LOOK 01 — FORTIFIED STUDIO", subtitle: "Black Permanent Art Tee", span: "md:col-span-1", ratio: "aspect-[4/5]", position: "object-[58%_center]" },
  { img: IMG.lookbook2, title: "LOOK 02 — CLASSIC WHITE", subtitle: "Front Print Presentation", span: "md:col-span-1", ratio: "aspect-[4/5]", position: "object-[72%_center]" },
  { img: IMG.lookbook1, title: "LOOK 03 — PERMANENT ART", subtitle: "Signature Back Print", span: "md:col-span-1", ratio: "aspect-[4/5]", position: "object-center" },
  { img: IMG.lookbook0, title: "LOOK 04 — QUIET STRENGTH", subtitle: "Embroidered Chest Detail", span: "md:col-span-1", ratio: "aspect-[4/5]", position: "object-[70%_center]" },
  { img: IMG.lookbook1, title: "LOOK 05 — THE FULL ARCHIVE", subtitle: "Fortified Permanent Art", span: "md:col-span-2", ratio: "aspect-[16/9]", position: "object-center" },
  { img: IMG.lookbook2, title: "LOOK 06 — WHITE STUDY", subtitle: "Premium Cotton Collection", span: "md:col-span-1", ratio: "aspect-[4/5]", position: "object-[66%_center]" },
];

export default function Lookbook() {
  // Lightbox States
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  return (
    <div className="pt-36">
      <div className="mx-auto max-w-[1600px] px-6 md:px-12">
        <motion.p
          initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          className="font-mono text-[10px] uppercase tracking-[0.4em] text-[#555]"
        >
          Editorial · SS Volume 01
        </motion.p>
        <h1 className="mt-4 font-display text-6xl font-black tracking-monolith text-white md:text-8xl">Lookbook</h1>
        <p className="mt-6 max-w-md text-[#A8A8A8]">
          Shot in raw concrete. Framed in shadow. A study of permanence in motion.
        </p>
      </div>

      {/* Campaign Film Section */}
      <div className="mx-auto mt-16 max-w-[1600px] px-6 md:px-12">
        <Reveal>
          <CampaignVideoPlayer aspectRatio="aspect-[16/9]" />
        </Reveal>
      </div>

      <div className="mx-auto mt-16 grid max-w-[1600px] grid-cols-1 gap-4 px-6 pb-28 md:grid-cols-3 md:px-12">
        {shots.map((s, i) => (
          <Reveal key={i} delay={(i % 3) * 0.1} className={s.span}>
            <div 
              className={`group relative overflow-hidden ${s.ratio} cursor-pointer rounded-sm border border-neutral-900 bg-neutral-950`}
              onClick={() => {
                setLightboxIndex(i);
                setLightboxOpen(true);
              }}
            >
              {s.img ? (
                <img src={s.img} alt={`${s.title}: ${s.subtitle}`} referrerPolicy="no-referrer" className={`h-full w-full object-cover ${s.position} transition-transform duration-700 group-hover:scale-[1.02]`} />
              ) : (
                <div className="absolute inset-0 bg-gradient-to-br from-[#111] to-[#050505] p-6 flex flex-col justify-between">
                  <span className="font-mono text-[9px] uppercase tracking-[0.3em] text-neutral-600">EDITORIAL ARCHIVE</span>
                </div>
              )}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all duration-300 flex items-end p-6">
                <span className="font-mono text-[9px] uppercase tracking-[0.25em] text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/70 backdrop-blur-md px-3 py-1.5 border border-white/20 rounded-sm w-fit">
                  View Fullscreen
                </span>
              </div>
            </div>
          </Reveal>
        ))}
      </div>

      <Lightbox
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        images={shots.map((s) => s.img)}
        initialIndex={lightboxIndex}
      />
    </div>
  );
}
